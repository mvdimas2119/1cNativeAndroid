
/////////////////////////////////////////////////////////////////////////////////////////////////////
//
// Examples for the report "Making external components for 1C mobile platform for Android""
// at the conference INFOSTART 2018 EVENT EDUCATION https://event.infostart.ru/2018/
//
// Sample 1: Delay in code
// Sample 2: Getting device information
// Sample 3: Device blocking: receiving external event about changing of sceen
//
// Copyright: Igor Kisil 2018
//
/////////////////////////////////////////////////////////////////////////////////////////////////////

package ru.infostart.education1;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import ru.infostart.education1.device.Utility;
import ru.infostart.education1.device.VH73Device;


// SAMPLE 3

public class LockState implements Runnable {

  // in C/C++ code the function will have name Java__ru_infostart_education_LockState_OnLockChanged
  static native void OnLockChanged(long pObject);
  static native void OnReadDataRFID(long pObject,String sValue);
  static native void OnReadCellRFID(long pObject,String sValue);

  //static native Set<BluetoothDevice> GetBluetoothDevices();

  private long m_V8Object; // 1C application context
  private Activity m_Activity; // custom activity of 1C:Enterprise
  private BroadcastReceiver m_Receiver;
  BluetoothAdapter mBluetoothAdapter;
  VH73Device currentDevice;
  Map<String, Integer> epc2num = new ConcurrentHashMap<String, Integer>();


  // Create the Handler
  private Handler handlerInventory = new Handler();

  Thread threadInventory = new Thread(new Runnable() {
    @Override
    public void run() {
      //OnReadDataRFID(m_V8Object, "Запуск потока");
      try {

        while(true) {
          try {
            // Insert custom code here
            currentDevice.listTagID(1, 0, 0);
            byte[] ret = currentDevice.getCmdResultWithTimeout(300);

            if (ret == null)
            {
              Thread.sleep(300);
              OnReadDataRFID(m_V8Object, "null");
              continue;
            }

            VH73Device.ListTagIDResult listTagIDResult = VH73Device
                    .parseListTagIDResult(ret);
            //addEpc(listTagIDResult);

            /*XStream xStream = new XStream(new DomDriver());
            xStream.alias("map", java.util.Map.class);
            String data = xStream.toXML(epc2num);*/

            ArrayList<byte[]> epcs = listTagIDResult.epcs;
            for (byte[] bs : epcs) {
              String string = Utility.bytes2HexString(bs);

              if (string.length() > 0) {
                OnReadDataRFID(m_V8Object, string);
              }

            }
            Thread.sleep(300);
          }
          catch (Exception e1)
          {

          }
        }
      }
      catch (Exception e)
      {
        OnReadDataRFID(m_V8Object, "1" + e.getMessage());
      }
    }
  });

  public LockState(Activity activity, long v8Object)
  {
    m_Activity = activity;
    m_V8Object = v8Object;
  }


  private void addEpc(VH73Device.ListTagIDResult list) {
    ArrayList<byte[]> epcs = list.epcs;
    for (byte[] bs : epcs) {
      String string = Utility.bytes2HexString(bs);
      if (epc2num.containsKey(string)) {
        epc2num.put(string, epc2num.get(string) + 1);
      } else {
        epc2num.put(string, 1);
      }
    }
  }

  @Override
  protected void finalize() throws Throwable {
    super.finalize();
    stopConnect();
  }

  public void run()
  {
    //System.loadLibrary("ru_infostart_education");
    System.loadLibrary("ru_infostart_education_1_100");

  }

  public void show()
  {
    m_Activity.runOnUiThread(this);
  }

  public void start()
  {
    if (m_Receiver==null)
    {
      m_Receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
          switch (intent.getAction())
          {
            case Intent.ACTION_SCREEN_ON:
              OnLockChanged(m_V8Object);
              break;
          }
        }
      };

      IntentFilter filter = new IntentFilter(Intent.ACTION_SCREEN_ON);
      m_Activity.registerReceiver(m_Receiver, filter);
    }
  }
  public String GetBluetoothDevices()
  {
      mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
      Set<BluetoothDevice> pairedDevices = mBluetoothAdapter.getBondedDevices();
      Map<String,String> retVal = new HashMap<>();
      for (BluetoothDevice blDev : pairedDevices)
    {
      retVal.put(blDev.getAddress().toString(),blDev.getName().toString());
    }

    XStream xStream = new XStream(new DomDriver());
    xStream.alias("map", java.util.Map.class);
    String xml = xStream.toXML(retVal);

      return xml;
  }
  private Boolean initBluetoothDevice()
  {
    mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
    Set<BluetoothDevice> pairedDevices = mBluetoothAdapter.getBondedDevices();
    if (pairedDevices.size() > 0) {
      for (BluetoothDevice device : pairedDevices) {
        int i = 0;
        if (device.getAddress().equals("88:1B:99:28:2C:C4"))
        {
          currentDevice =   new VH73Device(this, device);

        }
      }

    }
    if (currentDevice == null)
    {
      return false;
    }
    return true;
  }
public void startConnect()
{
  if (currentDevice != null)
  {
    if (currentDevice.connect())
    {
      //inventoryThread.start();
      // Start the Runnable immediately
      //handlerInventory.post(runnableInventory);
      threadInventory.start();
    }
  }
  else
  {
    initBluetoothDevice();
    if (currentDevice != null) {
      if (currentDevice.connect())
      {
        //inventoryThread.execute();

        // Start the Runnable immediately
        //handlerInventory.post(runnableInventory);
        threadInventory.start();
      }
    }
  }
  //OnReadDataRFID(m_V8Object,"Test OnRead");
  //OnReadDataRFID(m_V8Object,"Test Read");
  //OnLockChanged(m_V8Object);
}
  public void stopConnect()
  {
    if (currentDevice != null)
    {
      try {
        threadInventory.stop();
        currentDevice.disconnect();
      } catch (IOException e) {
        e.printStackTrace();
      }

    }
  }
//String sAddresRFID, int cellID
  public void readDataRFID()
  {
    /*try {
      if (currentDevice != null)
      {
        if (currentDevice.isConnected())
        {


            //currentDevice.listTagID(cellID, 0, 0);
            /*currentDevice.ReadWordBlock(sAddresRFID,cellID,0,0,null);
            byte[] ret  = currentDevice.getCmdResultWithTimeout(300);

            VH73Device.ListTagIDResult listTagIDResult = VH73Device
                    .parseListTagIDResult(ret);

            ArrayList<byte[]> epcs = listTagIDResult.epcs;
            for (byte[] bs : epcs) {
              String string = Utility.bytes2HexString(bs);

              if (string.length() > 0) {
                //OnReadDataRFID(m_V8Object, string);
                OnReadCellRFID(m_V8Object,string);
              }
            }
            //OnReadCellRFID(m_V8Object,"Тест четения ячейки");

          }

        }
      }
    catch (Exception e)
    {
      //OnReadCellRFID(m_V8Object,"Ошибка четения ячейки");
    }*/
  }
  public void WriteData(String sAddresRFID,int cellID,String sData)
  {
    if (currentDevice != null)
    {
      if (currentDevice.isConnected())
      {
        try {


          /*currentDevice.ReadWordBlock(sAddresRFID,cellID,0,0,null);
          byte[] ret  = currentDevice.getCmdResultWithTimeout(300);

          VH73Device.ListTagIDResult listTagIDResult = VH73Device
                  .parseListTagIDResult(ret);

          ArrayList<byte[]> epcs = listTagIDResult.epcs;
          for (byte[] bs : epcs) {
            String string = Utility.bytes2HexString(bs);

            if (string.length() > 0) {
              //OnReadDataRFID(m_V8Object, string);
              OnReadCellRFID(m_V8Object,string);
            }
          }*/


        }
        catch (Exception e)
        {

        }
      }
    }

  }

  public void ControlTest()
  {

  }

  public String GetTestJava()
  {
    OnReadDataRFID(m_V8Object,"Test Java in C++");
    return "Test Java in C+++";
  }


  public void stop()
  {
    if (m_Receiver != null)
    {
      m_Activity.unregisterReceiver(m_Receiver);
      m_Receiver = null;
    }
  }
}
