package ru.infostart.education1.device;

public class TimeoutException extends Exception {
	private static final long serialVersionUID = -1279364037378764398L;
}
